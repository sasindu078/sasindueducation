import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { streams } from '@/lib/data';
import Navigation from '@/components/Navigation';
import { BookOpen, Users, Award, Target } from 'lucide-react';

export default function Index() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Welcome to <span className="text-blue-600">A/L Education Hub</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Your comprehensive platform for Advanced Level education. Choose your stream and start practicing with our extensive MCQ collection.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-sm">
              <BookOpen className="h-12 w-12 text-blue-600 mb-3" />
              <h3 className="font-semibold text-gray-900">5 Streams</h3>
              <p className="text-sm text-gray-600 text-center">Complete coverage of all A/L streams</p>
            </div>
            <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-sm">
              <Users className="h-12 w-12 text-green-600 mb-3" />
              <h3 className="font-semibold text-gray-900">Expert Content</h3>
              <p className="text-sm text-gray-600 text-center">Curated by education professionals</p>
            </div>
            <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-sm">
              <Award className="h-12 w-12 text-purple-600 mb-3" />
              <h3 className="font-semibold text-gray-900">Practice Tests</h3>
              <p className="text-sm text-gray-600 text-center">Comprehensive MCQ practice</p>
            </div>
            <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-sm">
              <Target className="h-12 w-12 text-red-600 mb-3" />
              <h3 className="font-semibold text-gray-900">Track Progress</h3>
              <p className="text-sm text-gray-600 text-center">Monitor your improvement</p>
            </div>
          </div>
        </div>

        {/* Streams Section */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Choose Your Stream</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {streams.map((stream) => (
              <Card key={stream.id} className="hover:shadow-lg transition-shadow duration-300 border-2 hover:border-blue-300">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl font-bold text-gray-900">{stream.displayName}</CardTitle>
                  <CardDescription className="text-gray-600">
                    Subjects: {stream.subjects.map(s => s.displayName).join(', ')}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Link to={`/stream/${stream.id}`}>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors">
                      Explore Subjects
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-gray-600">
          <p>&copy; 2024 A/L Education Hub. Empowering students for success.</p>
        </div>
      </div>
    </div>
  );
}