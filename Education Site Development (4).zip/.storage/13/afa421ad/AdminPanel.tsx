import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getMCQs, addMCQ, deleteMCQ, streams, MCQ } from '@/lib/data';
import Navigation from '@/components/Navigation';
import { Trash2, Plus, Lock, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminPanel() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [mcqs, setMcqs] = useState<MCQ[]>([]);
  const [newMCQ, setNewMCQ] = useState({
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    subject: '',
    stream: ''
  });

  const ADMIN_PASSWORD = '123Sasindu#';

  useEffect(() => {
    if (isAuthenticated) {
      setMcqs(getMCQs());
    }
  }, [isAuthenticated]);

  const handleLogin = () => {
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setPassword('');
      toast.success('Successfully logged in to Admin Panel');
    } else {
      toast.error('Incorrect password. Please try again.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setPassword('');
    toast.success('Successfully logged out');
  };

  const handleAddMCQ = () => {
    if (!newMCQ.question || !newMCQ.subject || !newMCQ.stream) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (newMCQ.options.some(option => !option.trim())) {
      toast.error('Please fill in all answer options');
      return;
    }

    const addedMCQ = addMCQ(newMCQ);
    setMcqs(getMCQs());
    setNewMCQ({
      question: '',
      options: ['', '', '', ''],
      correctAnswer: 0,
      subject: '',
      stream: ''
    });
    toast.success('MCQ added successfully');
  };

  const handleDeleteMCQ = (id: string) => {
    deleteMCQ(id);
    setMcqs(getMCQs());
    toast.success('MCQ deleted successfully');
  };

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...newMCQ.options];
    newOptions[index] = value;
    setNewMCQ({ ...newMCQ, options: newOptions });
  };

  const getSubjectsForStream = (streamId: string) => {
    const stream = streams.find(s => s.id === streamId);
    return stream ? stream.subjects : [];
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Navigation />
        
        <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <Lock className="h-12 w-12 text-blue-600" />
              </div>
              <CardTitle className="text-2xl">Admin Login</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="password">Admin Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                      placeholder="Enter admin password"
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
                <Button onClick={handleLogin} className="w-full">
                  Login to Admin Panel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
          <Button onClick={handleLogout} variant="outline">
            Logout
          </Button>
        </div>

        {/* Add New MCQ Section */}
        <Card className="shadow-lg mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="h-6 w-6" />
              <span>Add New MCQ</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="stream">Stream</Label>
                <Select value={newMCQ.stream} onValueChange={(value) => setNewMCQ({ ...newMCQ, stream: value, subject: '' })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select stream" />
                  </SelectTrigger>
                  <SelectContent>
                    {streams.map((stream) => (
                      <SelectItem key={stream.id} value={stream.id}>
                        {stream.displayName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="subject">Subject</Label>
                <Select 
                  value={newMCQ.subject} 
                  onValueChange={(value) => setNewMCQ({ ...newMCQ, subject: value })}
                  disabled={!newMCQ.stream}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {getSubjectsForStream(newMCQ.stream).map((subject) => (
                      <SelectItem key={subject.id} value={subject.name}>
                        {subject.displayName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="question">Question</Label>
              <Textarea
                id="question"
                value={newMCQ.question}
                onChange={(e) => setNewMCQ({ ...newMCQ, question: e.target.value })}
                placeholder="Enter the MCQ question"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {newMCQ.options.map((option, index) => (
                <div key={index}>
                  <Label htmlFor={`option-${index}`}>Option {String.fromCharCode(65 + index)}</Label>
                  <Input
                    id={`option-${index}`}
                    value={option}
                    onChange={(e) => handleOptionChange(index, e.target.value)}
                    placeholder={`Enter option ${String.fromCharCode(65 + index)}`}
                  />
                </div>
              ))}
            </div>

            <div>
              <Label htmlFor="correct-answer">Correct Answer</Label>
              <Select 
                value={newMCQ.correctAnswer.toString()} 
                onValueChange={(value) => setNewMCQ({ ...newMCQ, correctAnswer: parseInt(value) })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select correct answer" />
                </SelectTrigger>
                <SelectContent>
                  {newMCQ.options.map((_, index) => (
                    <SelectItem key={index} value={index.toString()}>
                      Option {String.fromCharCode(65 + index)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button onClick={handleAddMCQ} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add MCQ
            </Button>
          </CardContent>
        </Card>

        {/* Existing MCQs Section */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Manage Existing MCQs ({mcqs.length} total)</CardTitle>
          </CardHeader>
          <CardContent>
            {mcqs.length === 0 ? (
              <p className="text-gray-600 text-center py-8">No MCQs available. Add some questions to get started.</p>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {mcqs.map((mcq) => (
                  <div key={mcq.id} className="border rounded-lg p-4 bg-white">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <div className="text-sm text-gray-600 mb-1">
                          {streams.find(s => s.id === mcq.stream)?.displayName} - {' '}
                          {streams.flatMap(s => s.subjects).find(sub => sub.name === mcq.subject)?.displayName}
                        </div>
                        <h3 className="font-semibold text-gray-900 mb-2">{mcq.question}</h3>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {mcq.options.map((option, index) => (
                            <div 
                              key={index} 
                              className={`p-2 rounded ${index === mcq.correctAnswer ? 'bg-green-100 text-green-800' : 'bg-gray-100'}`}
                            >
                              {String.fromCharCode(65 + index)}. {option}
                            </div>
                          ))}
                        </div>
                      </div>
                      <Button
                        onClick={() => handleDeleteMCQ(mcq.id)}
                        variant="destructive"
                        size="sm"
                        className="ml-4"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}