import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { GraduationCap } from 'lucide-react';

export default function Navigation() {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-md border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <GraduationCap className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">A/L Education Hub</span>
          </Link>
          
          <div className="flex space-x-4">
            <Link to="/">
              <Button 
                variant={isActive('/') ? 'default' : 'ghost'}
                className="text-sm font-medium"
              >
                Home
              </Button>
            </Link>
            <Link to="/about">
              <Button 
                variant={isActive('/about') ? 'default' : 'ghost'}
                className="text-sm font-medium"
              >
                About Us
              </Button>
            </Link>
            <Link to="/contact">
              <Button 
                variant={isActive('/contact') ? 'default' : 'ghost'}
                className="text-sm font-medium"
              >
                Contact Us
              </Button>
            </Link>
            <Link to="/admin">
              <Button 
                variant={isActive('/admin') ? 'default' : 'ghost'}
                className="text-sm font-medium"
              >
                Admin
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}