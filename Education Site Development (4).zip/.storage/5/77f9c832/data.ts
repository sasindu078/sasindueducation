export interface MCQ {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  subject: string;
  stream: string;
}

export interface Subject {
  id: string;
  name: string;
  displayName: string;
}

export interface Stream {
  id: string;
  name: string;
  displayName: string;
  subjects: Subject[];
}

export const streams: Stream[] = [
  {
    id: 'biology',
    name: 'biology',
    displayName: 'Biology Stream',
    subjects: [
      { id: 'bio', name: 'bio', displayName: 'Biology' },
      { id: 'physics', name: 'physics', displayName: 'Physics' },
      { id: 'chemistry', name: 'chemistry', displayName: 'Chemistry' }
    ]
  },
  {
    id: 'mathematics',
    name: 'mathematics', 
    displayName: 'Mathematics Stream',
    subjects: [
      { id: 'maths', name: 'maths', displayName: 'Mathematics' },
      { id: 'physics', name: 'physics', displayName: 'Physics' },
      { id: 'chemistry', name: 'chemistry', displayName: 'Chemistry' }
    ]
  },
  {
    id: 'commerce',
    name: 'commerce',
    displayName: 'Commerce Stream', 
    subjects: [
      { id: 'account', name: 'account', displayName: 'Accounting' },
      { id: 'business', name: 'business', displayName: 'Business Studies' },
      { id: 'econ', name: 'econ', displayName: 'Economics' }
    ]
  },
  {
    id: 'arts',
    name: 'arts',
    displayName: 'Arts Stream',
    subjects: [
      { id: 'sinhala', name: 'sinhala', displayName: 'Sinhala' },
      { id: 'geography', name: 'geography', displayName: 'Geography' },
      { id: 'history', name: 'history', displayName: 'History' }
    ]
  },
  {
    id: 'technology',
    name: 'technology',
    displayName: 'Technology Stream',
    subjects: [
      { id: 'et', name: 'et', displayName: 'Engineering Technology' },
      { id: 'ict', name: 'ict', displayName: 'ICT' },
      { id: 'sft', name: 'sft', displayName: 'Science for Technology' }
    ]
  }
];

// Sample MCQ data
export const defaultMCQs: MCQ[] = [
  {
    id: '1',
    question: 'What is the powerhouse of the cell?',
    options: ['Nucleus', 'Mitochondria', 'Ribosome', 'Golgi apparatus'],
    correctAnswer: 1,
    subject: 'bio',
    stream: 'biology'
  },
  {
    id: '2', 
    question: 'What is the unit of force?',
    options: ['Joule', 'Newton', 'Watt', 'Pascal'],
    correctAnswer: 1,
    subject: 'physics',
    stream: 'biology'
  },
  {
    id: '3',
    question: 'What is the chemical symbol for Gold?',
    options: ['Go', 'Gd', 'Au', 'Ag'],
    correctAnswer: 2,
    subject: 'chemistry',
    stream: 'biology'
  }
];

// Local storage functions
export const getMCQs = (): MCQ[] => {
  const stored = localStorage.getItem('alEducationHub_mcqs');
  return stored ? JSON.parse(stored) : defaultMCQs;
};

export const saveMCQs = (mcqs: MCQ[]) => {
  localStorage.setItem('alEducationHub_mcqs', JSON.stringify(mcqs));
};

export const addMCQ = (mcq: Omit<MCQ, 'id'>) => {
  const mcqs = getMCQs();
  const newMCQ = { ...mcq, id: Date.now().toString() };
  mcqs.push(newMCQ);
  saveMCQs(mcqs);
  return newMCQ;
};

export const deleteMCQ = (id: string) => {
  const mcqs = getMCQs();
  const filtered = mcqs.filter(mcq => mcq.id !== id);
  saveMCQs(filtered);
};

export const getMCQsBySubject = (subject: string): MCQ[] => {
  const mcqs = getMCQs();
  return mcqs.filter(mcq => mcq.subject === subject);
};