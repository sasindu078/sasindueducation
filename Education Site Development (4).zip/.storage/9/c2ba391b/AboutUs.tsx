import Navigation from '@/components/Navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { GraduationCap, Target, Users, Award } from 'lucide-react';

export default function AboutUs() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About A/L Education Hub</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Empowering Sri Lankan students to excel in their Advanced Level examinations through comprehensive online education resources.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-6 w-6 text-blue-600" />
                <span>Our Mission</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 leading-relaxed">
                To provide high-quality, accessible education resources for Advanced Level students in Sri Lanka. 
                We aim to bridge the gap between traditional classroom learning and modern digital education, 
                ensuring every student has the tools they need to succeed in their A/L examinations.
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <GraduationCap className="h-6 w-6 text-green-600" />
                <span>Our Vision</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 leading-relaxed">
                To become the leading online education platform for A/L students in Sri Lanka, 
                fostering academic excellence and preparing students for higher education and future careers. 
                We envision a future where quality education is accessible to all students, regardless of their location.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mb-12">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">What We Offer</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center">
                <Users className="h-12 w-12 text-purple-600 mx-auto mb-3" />
                <CardTitle>Comprehensive Coverage</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Complete coverage of all five A/L streams: Biology, Mathematics, Commerce, Arts, and Technology, 
                  with detailed subject-wise content and practice materials.
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center">
                <Award className="h-12 w-12 text-red-600 mx-auto mb-3" />
                <CardTitle>MCQ Practice</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  Extensive collection of Multiple Choice Questions for each subject, 
                  designed to help students practice and prepare effectively for their examinations.
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center">
                <Target className="h-12 w-12 text-blue-600 mx-auto mb-3" />
                <CardTitle>Easy Access</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center">
                  User-friendly interface that makes learning enjoyable and accessible. 
                  Navigate easily between streams, subjects, and practice tests.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="mb-12">
          <Card className="shadow-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
            <CardContent className="pt-8 pb-8">
              <div className="text-center">
                <h2 className="text-3xl font-bold mb-4">Our Commitment</h2>
                <p className="text-lg text-blue-100 max-w-4xl mx-auto leading-relaxed">
                  We are committed to continuously updating our content, adding new questions, and improving our platform 
                  based on student feedback and educational requirements. Our goal is to support every student's journey 
                  towards academic success and help them achieve their dreams of higher education.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Join Our Learning Community</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Start your journey with A/L Education Hub today and take the first step towards academic excellence. 
            Together, we can achieve your educational goals and build a brighter future.
          </p>
        </div>
      </div>
    </div>
  );
}