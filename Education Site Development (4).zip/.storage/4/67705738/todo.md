# A/L Education Hub - MVP Development Plan

## Core Features to Implement:

### 1. Main Components (8 files max):
- **src/pages/Index.tsx** - Home page with 5 main streams
- **src/pages/ContactUs.tsx** - Contact page with email and phone
- **src/pages/AboutUs.tsx** - About page with site description
- **src/pages/StreamSubjects.tsx** - Shows subjects for selected stream
- **src/pages/MCQQuiz.tsx** - MCQ questions for selected subject
- **src/pages/AdminPanel.tsx** - Admin login and MCQ management
- **src/components/Navigation.tsx** - Navigation bar component
- **src/lib/data.ts** - Data structure for streams, subjects, and MCQs

### 2. Data Structure:
- **5 Main Streams:**
  - Biology: Bio, Physics, Chemistry
  - Mathematics: Maths, Physics, Chemistry  
  - Commerce: Account, Business Study, Econ
  - Arts: Sinhala, Geography, History
  - Technology: ET, ICT, SFT

### 3. Features:
- Navigation between pages
- Stream selection → Subject selection → MCQ quiz
- Admin panel with password authentication (123Sasindu#)
- Add/Delete MCQ functionality
- Local storage for data persistence
- Responsive design

### 4. Pages Flow:
Home → Stream Selection → Subject Selection → MCQ Quiz
Admin Panel (separate access) → MCQ Management

### 5. Contact Info:
- Email: sasindun51@gmail.com
- Phone: 0774778467