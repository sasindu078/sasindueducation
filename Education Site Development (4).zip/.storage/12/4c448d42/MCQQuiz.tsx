import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { getMCQsBySubject, streams } from '@/lib/data';
import Navigation from '@/components/Navigation';
import { ArrowLeft, CheckCircle, XCircle, RotateCcw } from 'lucide-react';

export default function MCQQuiz() {
  const { subject } = useParams();
  const [mcqs, setMcqs] = useState(() => getMCQsBySubject(subject || ''));
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredQuestions, setAnsweredQuestions] = useState<boolean[]>([]);

  const subjectDisplayName = streams
    .flatMap(stream => stream.subjects)
    .find(s => s.name === subject)?.displayName || subject;

  useEffect(() => {
    const newMcqs = getMCQsBySubject(subject || '');
    setMcqs(newMcqs);
    setAnsweredQuestions(new Array(newMcqs.length).fill(false));
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
  }, [subject]);

  if (mcqs.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">No Questions Available</h1>
          <p className="text-gray-600 mb-6">
            There are no MCQ questions available for {subjectDisplayName} yet.
          </p>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const currentMCQ = mcqs[currentIndex];
  const progress = ((currentIndex + 1) / mcqs.length) * 100;

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNext = () => {
    if (selectedAnswer !== null) {
      const newAnsweredQuestions = [...answeredQuestions];
      newAnsweredQuestions[currentIndex] = true;
      setAnsweredQuestions(newAnsweredQuestions);

      if (selectedAnswer === currentMCQ.correctAnswer) {
        setScore(score + 1);
      }

      if (currentIndex < mcqs.length - 1) {
        setCurrentIndex(currentIndex + 1);
        setSelectedAnswer(null);
        setShowResult(false);
      } else {
        // Quiz completed
        setShowResult(true);
      }
    }
  };

  const handleShowAnswer = () => {
    setShowResult(true);
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnsweredQuestions(new Array(mcqs.length).fill(false));
  };

  const isQuizCompleted = currentIndex === mcqs.length - 1 && answeredQuestions[currentIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <Link to="/">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{subjectDisplayName} MCQ Quiz</h1>
            <p className="text-gray-600">Question {currentIndex + 1} of {mcqs.length}</p>
            <Progress value={progress} className="mt-4 max-w-md mx-auto" />
          </div>
        </div>

        {isQuizCompleted ? (
          <Card className="shadow-lg max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-green-600">Quiz Completed!</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="mb-6">
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  {score}/{mcqs.length}
                </div>
                <div className="text-gray-600">
                  Your Score: {Math.round((score / mcqs.length) * 100)}%
                </div>
              </div>
              
              <div className="space-y-4">
                <Button onClick={handleRestart} className="w-full">
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Restart Quiz
                </Button>
                <Link to="/" className="block">
                  <Button variant="outline" className="w-full">
                    Back to Home
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl">{currentMCQ.question}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 mb-6">
                {currentMCQ.options.map((option, index) => (
                  <Button
                    key={index}
                    variant={selectedAnswer === index ? "default" : "outline"}
                    className={`w-full text-left justify-start p-4 h-auto ${
                      showResult
                        ? index === currentMCQ.correctAnswer
                          ? 'bg-green-100 border-green-500 text-green-800'
                          : selectedAnswer === index && index !== currentMCQ.correctAnswer
                          ? 'bg-red-100 border-red-500 text-red-800'
                          : ''
                        : ''
                    }`}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={showResult}
                  >
                    <span className="mr-3 font-semibold">
                      {String.fromCharCode(65 + index)}.
                    </span>
                    {option}
                    {showResult && index === currentMCQ.correctAnswer && (
                      <CheckCircle className="h-5 w-5 ml-auto text-green-600" />
                    )}
                    {showResult && selectedAnswer === index && index !== currentMCQ.correctAnswer && (
                      <XCircle className="h-5 w-5 ml-auto text-red-600" />
                    )}
                  </Button>
                ))}
              </div>

              <div className="flex space-x-4">
                {!showResult ? (
                  <>
                    <Button
                      onClick={handleShowAnswer}
                      variant="outline"
                      disabled={selectedAnswer === null}
                      className="flex-1"
                    >
                      Show Answer
                    </Button>
                    <Button
                      onClick={handleNext}
                      disabled={selectedAnswer === null}
                      className="flex-1"
                    >
                      {currentIndex === mcqs.length - 1 ? 'Finish Quiz' : 'Next Question'}
                    </Button>
                  </>
                ) : (
                  <Button
                    onClick={handleNext}
                    className="w-full"
                  >
                    {currentIndex === mcqs.length - 1 ? 'Finish Quiz' : 'Next Question'}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}