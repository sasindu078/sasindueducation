import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { streams, getMCQsBySubject } from '@/lib/data';
import Navigation from '@/components/Navigation';
import { ArrowLeft, BookOpen } from 'lucide-react';

export default function StreamSubjects() {
  const { streamId } = useParams();
  const stream = streams.find(s => s.id === streamId);

  if (!stream) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h1 className="text-2xl font-bold text-gray-900">Stream not found</h1>
          <Link to="/">
            <Button className="mt-4">Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <Link to="/">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Streams
            </Button>
          </Link>
          
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">{stream.displayName}</h1>
            <p className="text-xl text-gray-600">
              Choose a subject to start practicing MCQ questions
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stream.subjects.map((subject) => {
            const mcqCount = getMCQsBySubject(subject.name).length;
            
            return (
              <Card key={subject.id} className="hover:shadow-lg transition-shadow duration-300 border-2 hover:border-blue-300">
                <CardHeader className="pb-4">
                  <div className="flex items-center space-x-3 mb-2">
                    <BookOpen className="h-6 w-6 text-blue-600" />
                    <CardTitle className="text-xl font-bold text-gray-900">
                      {subject.displayName}
                    </CardTitle>
                  </div>
                  <div className="text-sm text-gray-600">
                    {mcqCount} MCQ questions available
                  </div>
                </CardHeader>
                <CardContent>
                  <Link to={`/mcq/${subject.name}`}>
                    <Button 
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
                      disabled={mcqCount === 0}
                    >
                      {mcqCount > 0 ? 'Start Practice' : 'No Questions Yet'}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <Card className="shadow-lg bg-blue-600 text-white max-w-2xl mx-auto">
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-2">Ready to Practice?</h3>
              <p className="text-blue-100">
                Select any subject above to start practicing with our MCQ questions. 
                Track your progress and improve your knowledge!
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}