import Navigation from '@/components/Navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail, Phone, MapPin, Clock } from 'lucide-react';

export default function ContactUs() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Contact Us</h1>
          <p className="text-xl text-gray-600">
            Get in touch with us for any questions or support
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Mail className="h-6 w-6 text-blue-600" />
                <span>Email Contact</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Send us an email for any inquiries or support requests.
              </p>
              <a 
                href="mailto:sasindun51@gmail.com" 
                className="text-blue-600 hover:text-blue-800 font-semibold text-lg"
              >
                sasindun51@gmail.com
              </a>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Phone className="h-6 w-6 text-green-600" />
                <span>Phone Contact</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Call us directly for immediate assistance.
              </p>
              <a 
                href="tel:0774778467" 
                className="text-green-600 hover:text-green-800 font-semibold text-lg"
              >
                0774778467
              </a>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-6 w-6 text-purple-600" />
                <span>Support Hours</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Weekdays</h3>
                  <p className="text-gray-600">Monday - Friday: 8:00 AM - 8:00 PM</p>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Weekends</h3>
                  <p className="text-gray-600">Saturday - Sunday: 9:00 AM - 6:00 PM</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 text-center">
          <Card className="shadow-lg bg-blue-600 text-white">
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-2">Need Help?</h3>
              <p className="text-blue-100">
                We're here to support your educational journey. Don't hesitate to reach out!
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}